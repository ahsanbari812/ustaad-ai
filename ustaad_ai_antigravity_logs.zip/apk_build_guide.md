# 📱 Building Your Ustaad AI APK — Beginner Guide

> [!IMPORTANT]
> Follow these steps **exactly in order**. Don't skip any step.

---

## Prerequisites (One-Time Setup)

Make sure you have these installed:
- ✅ **Node.js** (you already have this — it runs your Expo project)
- ✅ **npm** (comes with Node.js)

---

## Step 1: Install EAS CLI

Open a **new terminal** (not the one running Expo) and run:

```bash
npm install -g eas-cli
```

**What this does:** Installs Expo's build tool globally on your computer.

**Expected output:** You'll see a progress bar, then something like `added 1 package`.

---

## Step 2: Create an Expo Account

1. Go to **https://expo.dev/signup** in your browser
2. Create a free account (email + password)
3. **Remember your username and password** — you'll need them next

---

## Step 3: Login to EAS

In the same terminal, run:

```bash
eas login
```

It will ask:
```
? Email or username: › (type your expo.dev username)
? Password: › (type your password — it won't show characters, that's normal)
```

**Expected output:** `Logged in as yourname`

---

## Step 4: Navigate to Your Project

```bash
cd "c:\Users\Ahsan\Downloads\CHALLENGE 2\ustaad-ai"
```

---

## Step 5: Build the APK

Run this command:

```bash
eas build --platform android --profile preview
```

It will ask you some questions. Answer them like this:

| Question | Your Answer |
|----------|-------------|
| `Would you like to automatically create an EAS project?` | **Yes** (press Enter) |
| `Generate a new Android Keystore?` | **Yes** (press Enter) |

**What happens next:**
1. Your code gets uploaded to Expo's cloud servers
2. They build a real Android APK for you
3. This takes **10-15 minutes** — be patient!
4. You'll see a progress bar and build logs

**Expected output at the end:**
```
✔ Build finished
🤖 Android app:
   https://expo.dev/artifacts/eas/XXXXX.apk
```

---

## Step 6: Download the APK

1. **Copy the URL** from the terminal output
2. **Open it in your browser** — it will download a `.apk` file
3. The file will be something like `application-xxxxx.apk` (~30-50 MB)

---

## Step 7: Install on Your Phone

### Option A: Transfer via USB
1. Connect your Android phone to your computer via USB
2. Copy the `.apk` file to your phone's **Downloads** folder
3. On your phone, open **Files** app → **Downloads** → tap the `.apk`
4. If asked, enable **"Install from unknown sources"** → tap **Install**

### Option B: Send via WhatsApp/Drive
1. Upload the `.apk` to Google Drive
2. Open the Drive link on your phone
3. Download and install

### Option C: Direct on Phone
1. Open the Expo download URL directly in your phone's browser
2. It will download and prompt you to install

---

## Troubleshooting

### "Command not found: eas"
Run `npm install -g eas-cli` again, then close and reopen your terminal.

### Build fails with errors
Run this first to check for issues:
```bash
npx expo doctor
```
Fix any issues it reports, then try the build again.

### "Not logged in"
Run `eas login` again and re-enter your credentials.

### Build takes too long
Free tier builds can take 15-20 minutes if there's a queue. Paid plans build faster, but free is fine for a hackathon.

---

## Quick Reference (Copy-Paste Commands)

```bash
# 1. Install EAS
npm install -g eas-cli

# 2. Login
eas login

# 3. Go to project
cd "c:\Users\Ahsan\Downloads\CHALLENGE 2\ustaad-ai"

# 4. Build APK
eas build --platform android --profile preview
```

> [!TIP]
> After the first build, future builds are faster because the keystore is already generated. Just run the `eas build` command again.

> [!NOTE]
> The APK will work on any Android 7+ device. All features (chat, booking, dashboard, architecture) will work exactly as they do in development.
