# Google Maps Integration — Ustaad AI

## Overview
Lightweight Google Maps integration for the existing Ustaad AI hackathon MVP. Shows nearby providers on a map with markers, distances, and recommended provider highlighting.

## Files Changed/Created

| File | Action | Purpose |
|------|--------|---------|
| `data/providers.json` | **Modified** | Add `latitude`/`longitude` to all 22 providers |
| `utils/types.ts` | **Modified** | Add `latitude`/`longitude` to `Provider` interface |
| `utils/distance.ts` | **Created** | Haversine distance calculation utility |
| `components/ProvidersMap.tsx` | **Created** | Full map component with markers & callouts |
| `app/map.tsx` | **Created** | Dedicated map screen route |
| `app/_layout.tsx` | **Modified** | Register the new map route |
| `screens/HomeScreen.tsx` | **Modified** | Add map button in header |
| `app/index.tsx` | **Modified** | Add Maps feature card on landing |
| `app.json` | **Modified** | Add Google Maps API key config |
| `.env` / `.env.example` | **Modified** | Add `EXPO_PUBLIC_GOOGLE_MAPS_API_KEY` |

## Installation
```bash
npx expo install react-native-maps expo-location
```

## Architecture
- **No backend required** — all mock data from `providers.json`
- **Haversine formula** for distance — no paid APIs
- **Optional user location** via `expo-location` with graceful fallback
- **Dedicated map screen** keeps the chat UI uncluttered
